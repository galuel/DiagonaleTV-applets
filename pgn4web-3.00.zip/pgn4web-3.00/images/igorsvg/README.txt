Chess images from http://openclipart.org/search/?query=chess+symbols+set by
Igor Krizanovskij; as openclipart.org content the images are dedicated to the
Public Domain (http://creativecommons.org/publicdomain/zero/1.0/).
Minor modification to the original images from Paolo Casaschi.
